<template>
    <div>
        <p>Copy Righ</p>
    </div>
</template>