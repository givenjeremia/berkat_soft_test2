<template>
    <div id="test2" ref="test2">
      sadasdas
    </div>
  </template>

<script>
export default {
  name: 'Test'
}
</script>