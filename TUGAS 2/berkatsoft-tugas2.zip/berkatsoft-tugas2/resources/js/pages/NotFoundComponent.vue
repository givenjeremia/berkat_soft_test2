<template>
    <div class="container-fluid p-3">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h1>NOT FOUND</h1>
                <!-- <div class="card">
                    <div class="card-header">Sales Order Component</div>

                    <div class="card-body">
                        I'm an example component.
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
